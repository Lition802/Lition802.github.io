//LiteXLoader Dev Helper
/// <reference path="c:\Users\amsq\.vscode\extensions\moxicat.lxldevhelper-0.1.8/Library/JS/Api.js" /> 

const dir_path = './plugins/SVIP2/';

const data_path = dir_path + "data.json";
const config_path = dir_path + 'config.json';
const xuid2name = lxl.import("lxless:xuid2name");
const removeMoney = lxl.import("lxless:removeMoney");
const getMoney = lxl.import('lxless:getMoney');

if (File.exists(dir_path) == false) {
    File.mkdir(dir_path);
}
function checkFile(path,text){
    if (File.exists(path) == false) {
        File.writeTo(path, text);
    }
}

let LIZI = {
    "小型黑色药水气泡": "minecraft:arrow_spell_emitter",
    "小型黑烟": "minecraft:basic_smoke_particle",
    "大型白烟(模糊的)": "minecraft:camera_shoot_explosion",
    "大型白烟(爆炸式的)": "minecraft:knockback_roar_particle",
    "超大范围爆炸": "minecraft:dragon_death_explosion_emitter",
    "爱心": "minecraft:heart_particle",
    "红色弓箭拖尾(上升的)": "minecraft:rising_border_dust_particle",
    "暴击粒子": "minecraft:basic_crit_particle",
    "传送门粒子": "minecraft:basic_portal_particle",
    "末影粒子": "minecraft:end_chest",
    "云雾粒子": "minecraft:death_explosion_emitter",
    "白色小球粒子": "minecraft:balloon_gas_particle",
    "黑烟粒子": "minecraft:basic_somke_particle",
    "爆炸粒子": "minecraft:explosion_particle",
    "持续火焰粒子（不建议循环）": "minecraft:mobflame_emitter",
    "音符粒子": "minecraft:note_particle",
    "唤魔者魔咒（不建议循环）": "minecraft:evoker_spell",
    "存留时间较短的唤魔者魔咒（不建议循环）": "minecraft:splash_spell_emitter",
    "魔咒（散）": "minecraft:mobspell_emitter",
    "凋零例子（集中）": "minecraft:wither_boss_invulnerable",
    "鸡蛋破碎粒子": "minecraft:egg_destroy_emitter",
    "击退震慑粒子": "minecraft:knockback_roar_paticle",
    "不死图腾粒子": "minecraft:totem_particle",
    "火焰颗粒": "minecraft:basic_flame_particle",
    "水花飞溅粒子": "minecraft:water_splash_particle",
    "水滴粒子": "minecraft:water_wake_particle",
    "红石粉粒子": "minecraft:restone_ore_dust_particle",
    "村民生气时的粒子": "minecraft:villager_angry",
    "村民开心时的粒子": "minecraft:villager_happy"
}

checkFile(data_path,'{}');
checkFile(`${dir_path}/particle/op.json`,JSON.stringify(LIZI,null,'\t'));
checkFile(`${dir_path}particle/player.json`,JSON.stringify(LIZI,null,'\t'));
checkFile(config_path,JSON.stringify({up_level_minute:10,buy:10000,tips_level:3,particle_level:5},null,'\t'));

let op_particle = JSON.parse(file.readFrom(`${dir_path}/particle/op.json`));
let player_particle = JSON.parse(file.readFrom(`${dir_path}particle/player.json`));
let vip_data = JSON.parse(file.readFrom(data_path));
let cfg = JSON.parse(file.readFrom(config_path));

/**
 * 
 * @param {String} xuid 
 * @returns {playerdata}
 */
function get_player(xuid){
    return vip_data[xuid];
}

class playerdata{
    constructor(){
        let now = system.getTimeObj();
        this.particle = {
            enable : false,
            name : "minecraft:heart_particle"
        },
        this.joinTips = {
            enable : false,
            text : '欢迎VIP玩家{name}加入服务器'
        },
        this.level = 1,
        this.onlineTime = 0,
        this.finish_time = [now.Y,now.M+1,now.D],
        this.has = true
    }
}

function add_vip(xuid){
    if(vip_data[xuid]!=undefined){
        vip_data[xuid].has = true;
        vip_data[xuid].finish_time[1] += 1;
    }
    vip_data[xuid] = new playerdata();
    SAVE();
}

function SAVE(){
    file.writeTo(data_path,JSON.stringify(vip_data,null,'\t'));
}

function set_particle(pl,index){
    if(pl.isOP()){
        vip_data[pl.xuid].particle.name = Object.values(op_particle)[index];
    }else{
        vip_data[pl.xuid].particle.name = Object.values(player_particle)[index];
    }
    SAVE();
}

/**
 * 
 * @param {Player} pl 
 * @param {string} text 
 */
function sendMsg(pl,text){
    pl.sendModalForm('SVIP',text,'我知道了','取消',(pl)=>{});
}

function MainForm(pl){
    let fm = mc.newSimpleForm();
    let dt = get_player(pl.xuid);
    fm.setContent(`§l§e你好，§b${pl.name}§e，您的VIP到期时间为§4${dt.finish_time[0]}年${dt.finish_time[1]}月${dt.finish_time[2]}日§e，距离升级到下一等级(${dt.level+1})还需要在线§2${(dt.level*cfg.up_level_minute - dt.onlineTime).toFixed(1)}§e分钟`);
    fm.addButton('更改粒子效果','textures/ui/icon_trending');
    fm.addButton('更改进服提示','textures/ui/icon_sign');
    fm.addButton('vip续费','textures/ui/icon_deals');
    return fm;
}

/**
 * 
 * @param {Player} pl 
 * @param {*} dt 
 * @returns 
 */
function MainFunc(pl,dt){
    if(dt==null)return;
    switch(dt){
        case 0:
            if(get_player(pl.xuid).level < cfg.particle_level){
                sendMsg(pl,`§l§e权限不足，至少需要§4${cfg.particle_level}§e才能解锁此功能`);
                return;
            }
            pl.sendForm(EditParticleForm(pl.isOP()),EditParticleFunc);
            break;
        case 1:
            if(get_player(pl.xuid).level < cfg.tips_level){
                sendMsg(pl,`§l§e权限不足，至少需要§4${cfg.tips_level}§e才能解锁此功能`);
                return;
            }
            pl.sendForm(EditJoinTipsForm(pl.xuid),EditJoinTipsFunc);
            break;
        case 2:
            PayTimeForm(pl);
            break;
    }
}

function EditParticleForm(is_op){
    let fm = mc.newCustomForm();
    if(is_op){
        fm.addDropdown('§b选择你想要的粒子',Object.keys(op_particle));
    }else{
        fm.addDropdown('§b选择你想要的粒子',Object.keys(player_particle));
    }
    fm.addSwitch('§e是否开启此功能(§4关§r<=>§2开)§r',true);
    return fm;
}

function BuyVIP(pl){
    pl.sendModalForm('VIP',`你还不是VIP哦，是否现在就购买VIP权限？\n当前VIP价格：${cfg.buy}/月`,'是','否',(pl2,dt2)=>{
        if(dt2){
            if(getMoney(pl2.xuid) > cfg.buy){
                removeMoney(pl2.xuid,cfg.buy);
                add_vip(pl2.xuid);
                sendMsg(pl2,'§l§2VIP购买成功！');
            }else{
                sendMsg(pl2,`§l§4您的积分不足以购买VIP权限\n至少需要§4${cfg.buy}§2，您只有§e${getMoney(pl2.xuid)}`);
            }
        }
    });
}

function EditJoinTipsForm(xuid){
    let pl = get_player(xuid);
    let fm = mc.newCustomForm();
    fm.addInput('设置您的自定义进服提示','可以用{name}代替自己的名字',pl.joinTips.text);
    fm.addSwitch('§e是否开启此功能(§4关§r<=>§2开)§r',pl.joinTips.enable);
    return fm;
}

function EditJoinTipsFunc(pl,dt){
    if(dt==null)return;
    get_player(pl.xuid).joinTips.enable = dt[1];
    if(dt[1]){
        get_player(pl.xuid).joinTips.text = dt[0];
        SAVE();
        sendMsg(pl,`§2您的进服欢迎提示已经更改为：§r${dt[0].replace('{name}',pl.name)}`);
    }else{
        sendMsg(pl,'§4加入服务器欢迎提示已关闭');
    }
}

/**
 * 
 * @param {Player} pl 
 * @param {*} dt 
 * @returns 
 */
function EditParticleFunc(pl,dt){
    if(dt==null)return;
    get_player(pl.xuid).particle.enable = dt[1];
    if(dt[1]){
        set_particle(pl,dt[0]);
        sendMsg(pl,'§2粒子效果修改成功');
    }else{
        SAVE();
        sendMsg(pl,'§4粒子效果已关闭');
    }
}

/**
 * 
 * @param {Player} pl 
 */
 function PayTimeForm(pl){
     let timeobj = [];
     let dt = get_player(pl.xuid);
    if(dt.has){
        let y = dt.finish_time[0];
        let m = dt.finish_time[1];
        let d = dt.finish_time[2];
        if(m+1 > 12){
            y+=1;
            m=1;
        }else{
            m+=1
        }
        timeobj = [y,m,d];
    }else{
        let obj = system.getTimeObj();
        timeobj = [obj.Y,obj.M+1,obj.D];
    }
    pl.sendModalForm('VIP',`§l§2即将续费到§4${timeobj[0]}年${timeobj[1]}月${timeobj[2]}日§2，是否支付§e${cfg.buy}§2？`,'是','否',(pl2,dt2)=>{
        if(dt2){
            if(getMoney(pl2.xuid) > cfg.buy){
                removeMoney(pl2.xuid,cfg.buy);
                let dt2 = get_player(pl2.xuid);
                dt2.finish_time = timeobj;
                SAVE();
                sendMsg(pl2,'§2VIP续费成功！');
            }else{
                sendMsg(pl2,`§4您的积分不足以购买VIP权限\n至少需要${cfg.buy}，您只有${getMoney(pl2.xuid)}`);
            }
        }
    });
}

/**
 * 
 * @param {Player} pl 
 * @param {playerdata} vip 
 */
function checkTimeLevel(pl,vip){
    if(vip.onlineTime > vip.level*cfg.up_level_minute){
        sendMsg(pl,`§l§2恭喜你！你的在线时间计满§e${vip.level*cfg.up_level_minute}§2分钟，VIP等级升级到§4${vip.level +1}§2级！！`);
        vip.level += 1;
        vip.onlineTime = 0;
        SAVE();
    }
}

setInterval(() => {
    mc.getOnlinePlayers().forEach(pl=>{
        let vip = get_player(pl.xuid);
        if(vip==undefined)return;
        if(vip.has == false)return;
        if(vip.particle.enable){
            mc.spawnParticle(pl.pos,vip.particle.name);
        }
        vip.onlineTime +=  0.008;
        checkTimeLevel(pl,vip);
    });
}, 500);

setInterval(() => {
    SAVE();
}, 60*1000);

/*
mc.regPlayerCmd('vip','vip系统',(pl)=>{
    let dt = get_player(pl.xuid) ;
    if(dt == undefined){
        BuyVIP(pl);
        return;
    }
    if(dt.has == false){
        PayTimeForm(pl);
        return;
    }
    pl.sendForm(MainForm(pl),MainFunc);
});
*/
function checkTimeOut(dt){
    let now = system.getTimeObj();
    if(dt.finish_time[0] < now.Y){
        return true;
    }
    if(dt.finish_time[0] == now.Y && dt.finish_time[1] < now.M){
        return true;
    }
    if(dt.finish_time[1] == now.M && dt.finish_time[2] < now.D){
        return true;
    }
    return false;
}

mc.listen('onJoin',(pl)=>{
    let dt = get_player(pl.xuid);
    if(dt==undefined)return;
    if(dt.has == false)return;
    if(checkTimeOut(dt)){
        sendMsg(pl,'§4你的VIP已经过期啦');
        dt.has = false;
        SAVE();
        return;
    }
    if(dt.joinTips.enable){
        mc.broadcast(dt.joinTips.text.replace("{name}",pl.name),5);
    }
});

lxl.export(get_player,'svip:getPlayer');

log('加载成功！');

mc.listen("onServerStarted", () => {
    let cmd = mc.newCommand("vip", "vip system", PermType.GameMasters);
    cmd.setEnum("ListAction", ["gui"]);
    cmd.mandatory("action", ParamType.Enum, "ListAction", 1);
    cmd.overload(["ListAction"]);
    cmd.setCallback((_cmd, ori, out, res) => {
        switch (res.action) {
            case 'gui':
                ori.player.sendForm(MainForm(ori.player),MainFunc);
                return out.success('正在打开面板');
        }
    });
    cmd.setup();
});